import {Food } from "./app/shared/model/Food";

export const sample_foods: Food[] = [
    {
        id: '1',
        Restname: 'Mugg n Bean',
        Foodname: 'Open Sandwish',
        stars: 5,
        price: 150,
        imageUrl: '/assets/image/open sandwish.jpg',
        cookTime: 20,
        distance: 1.5
    },
    {
        id: '2',
        Restname: 'Cowfish',
        Foodname: '6pc Salmon Rainbow Roll',
        stars: 4.5,
        price: 150,
        imageUrl: '/assets/image/sushi.jpg',
        cookTime: 20,
        distance: 4
    },
    {
        id: '3',
        Restname: 'Tashas',
        Foodname: 'Pesto Pasta',
        stars: 5,
        price: 150,
        imageUrl: '/assets/image/Pasta.jpg',
        cookTime: 20,
        distance: 3
    },
    {
        id: '4',
        Restname: 'Hudsons',
        Foodname: 'Chicken Pizza',
        stars: 4,
        price: 200,
        imageUrl: '/assets/image/Pizza.jpg',
        cookTime: 30,
        distance: 4
    },
]