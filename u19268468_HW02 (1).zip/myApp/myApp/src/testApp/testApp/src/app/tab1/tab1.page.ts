import {  Component} from '@angular/core';
import { Food } from '../shared/model/Food';
import { FoodService } from '../services/food.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from '../shared/model/Cart';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
})
export class Tab1Page {
  food:Food[] = [];

  constructor(private api:FoodService, activatedRoute:ActivatedRoute, 
    private cartService:CartService, private router:Router) {
    //this.food = api.getAll(); //get all data return 
  

  activatedRoute.params.subscribe((params) => {
    if(params.searchTerm)
      this.food = this.api.getAllFoodBySearchTerm(params.searchTerm)
    else
    this.food = this.api.getAll();
  })
}

  ngOnInit(){}

  //add too cart button 
  addToCart(){
    //this.cartService.addTocart(this.food);

    this.router.navigateByUrl('/tab3')
  }
}
