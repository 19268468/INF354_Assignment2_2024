import { Injectable } from '@angular/core';
import { Cart } from '../shared/model/Cart';
import { BehaviorSubject } from 'rxjs';
import { Food } from '../shared/model/Food';
import { CartItem } from '../shared/model/CartItem';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart:Cart = new Cart();
  private cartSubject:BehaviorSubject<Cart> = new BehaviorSubject(this.cart);

  constructor() { }

  //add to cart method
  addTocart(food:Food):void{
    let cartItem = this.cart.items.find(item => item.food.id === food.id);
    if(cartItem)
      return;

    this.cart.items.push(new CartItem(food))
    this.setCartToLocalStorage();
  }

  //get cart oberservable 
  //getCartObservable():Observable<Cart>{
  //  return this.cartSubject.asObservable();
  //}

  //localStorage
  private setCartToLocalStorage():void {
    this.cart.totalPrice = this.cart.items.reduce((prevSum, currentItem) => 
      prevSum + currentItem.price, 0);
    this.cart.totalCount = this.cart.items.reduce((prevSum, currentItem) => 
      prevSum + currentItem.quantity, 0);

    const cartJson = JSON.stringify(this.cart);
    localStorage.setItem('Cart', cartJson);
    this.cartSubject.next(this.cart);
  }

  //whenever you set local storage data then also get data from local storage
  private getCartfromLocalStorage():Cart{
    const cartJson = localStorage.getItem('Cart');
    return cartJson?JSON.parse(cartJson):new Cart();
  }

}
