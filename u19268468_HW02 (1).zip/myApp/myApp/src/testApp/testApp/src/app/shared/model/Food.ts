export class Food {
    id!:string;
    Restname!:string;
    Foodname!:string;
    stars!: number;
    price!: number;
    imageUrl!: string;
    cookTime!: number;
    distance!: number;
}