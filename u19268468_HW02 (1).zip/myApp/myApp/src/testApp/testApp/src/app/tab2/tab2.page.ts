import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit{
  
  searchTerm=''
  constructor(activatedRoute:ActivatedRoute, private router:Router ) {
    activatedRoute.params.subscribe((params) => {
      if(params.searchTerm)
        this.searchTerm = params.searchTerm;
    });
  }
    
  
  ngOnInit(): void { 

  }

  search(term:string){
    if(term)
      this.router.navigateByUrl('/tab2/search/'+ term);
  }

}
